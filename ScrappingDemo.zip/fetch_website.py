import time

import requests
from bs4 import BeautifulSoup
from fetch_offer import grab_single_offer

def fetch_website():
    skill = input('Enter your skill : \n')
    html_text = requests.get(f'https://candidat.pole-emploi.fr/offres/recherche?lieux=75D&motsCles=python&offresPartenaires=true&rayon=10&tri=0').text
    soup = BeautifulSoup(html_text, 'lxml')
    offers = soup.find_all('li', class_='result')
    targets = []
    for current in offers:
        next_link = current.find('a').get('href').split('/')
        targets.append(next_link[len(next_link) - 1])
    print(targets)
    offers=[]
    print('Loading',end='')
    for target in targets:
        print('.',end='')
        offers.append(grab_single_offer(f'https://candidat.pole-emploi.fr/offres/recherche/detail/{target}'))
        #time.sleep(20)
    print('')
    for offer in offers:
        print(f'Experience : {offer.experience}')
        print(f'Nom : {offer.name}')
        print(f'Addresse : {offer.address}')
        print('--')

    """offer=grab_single_offer(f'https://candidat.pole-emploi.fr/offres/recherche/detail/166DXFK')
    print(f'Experience : {offer.experience}')
    print(f'Nom : {offer.name}')
    print(f'Addresse : {offer.address}')
    print('--')
    """
