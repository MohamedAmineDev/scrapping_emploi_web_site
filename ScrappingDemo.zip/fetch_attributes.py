
def fetch_experience(line):
    return line.find('span', class_='skill-name').text


def fetch_skills(line):
    ch = ''
    competences = line.find_all('span', class_='skill-name')
    for competence in competences:
        if len(ch) == 0:
            ch = f'{competence.text}'
        else:
            ch = f'{ch},{competence.text}'
    #print(ch)
    return ch


def fetch_langue(line):
    ch = ''
    languages = line.find_all('span', class_='skill-name')
    for language in languages:
        if len(ch) == 0:
            ch = f'{language.text}'
        else:
            ch = f'{ch},{language.text}'
    return ch


def fetch_title(soup):
    entreprise = soup.find('div', class_='media')
    name = entreprise.find('h3', class_='t4 title').text.strip()
    return name


def fetch_date(soup):
    date_element = soup.find('p', class_='t5 title-complementary')
    date_value = date_element.find('span').text.strip()
    return date_value


def fetch_address(soup):
    address_element = soup.find('span', itemprop='name')
    return address_element.text.strip()


def fetch_type_contract(soup):
    contract_element = soup.find('dl', class_='icon-group')
    contract_value = contract_element.find('dd')
    return contract_value.text.split('\n')[1]


def fetch_qualification(soup):
    qualification_element = soup.find('span', itemprop='qualifications')
    return qualification_element.text.strip()
