from fetch_website import fetch_website

#grab_single_offer('https://candidat.pole-emploi.fr/offres/recherche/detail/164YKZV')
#print('---------------------')
#grab_single_offer('https://candidat.pole-emploi.fr/offres/recherche/detail/166LHSN')
#print('---------------------')
#grab_single_offer('https://candidat.pole-emploi.fr/offres/recherche/detail/166BKXD')
fetch_website()
